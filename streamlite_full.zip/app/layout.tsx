import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'StreamLite',
  description: 'A minimal streaming dashboard clone'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-900 text-white min-h-screen">
        <header className="sticky top-0 z-50 bg-black/60 backdrop-blur p-4">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <Link href="/"><span className="font-bold text-xl">StreamLite</span></Link>
            <nav className="space-x-4">
              <Link href="/">Home</Link>
            </nav>
          </div>
        </header>
        <main className="max-w-6xl mx-auto px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
