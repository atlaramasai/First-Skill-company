import { fetchMovieById } from '../../../lib/tmdb';
import Image from 'next/image';

export default async function MoviePage({ params }: { params: { id: string } }) {
  const data = await fetchMovieById(params.id);
  const movie = data;

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="md:col-span-1">
        {movie.poster_path && (
          <Image
            src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
            alt={movie.title}
            width={400}
            height={600}
            style={{ objectFit: 'cover' }}
          />
        )}
      </div>
      <div className="md:col-span-2">
        <h1 className="text-2xl font-bold">{movie.title}</h1>
        <p className="mt-2 text-sm">{movie.overview}</p>
        <div className="mt-4 space-y-1">
          <div><strong>Release Date:</strong> {movie.release_date || 'N/A'}</div>
          <div><strong>Rating:</strong> {movie.vote_average ?? 'N/A'}</div>
          <div><strong>Genres:</strong> {movie.genres?.map((g:any) => g.name).join(', ') || 'N/A'}</div>
        </div>
      </div>
    </div>
  );
}
