const BASE = 'https://api.themoviedb.org/3';
const API_KEY = process.env.TMDB_API_KEY;

if (!API_KEY) {
  throw new Error('TMDB_API_KEY not found in environment variables');
}

async function fetchTmdb(path: string) {
  const res = await fetch(`${BASE}${path}&api_key=${API_KEY}`);
  if (!res.ok) {
    throw new Error(`TMDB fetch failed: ${res.status}`);
  }
  return res.json();
}

export async function fetchPopular() {
  return fetchTmdb(`/movie/popular?language=en-US&page=1`);
}

export async function fetchTopRated() {
  return fetchTmdb(`/movie/top_rated?language=en-US&page=1`);
}

export async function fetchNowPlaying() {
  return fetchTmdb(`/movie/now_playing?language=en-US&page=1`);
}

export async function fetchMovieById(id: string) {
  return fetchTmdb(`/movie/${id}?language=en-US`);
}
