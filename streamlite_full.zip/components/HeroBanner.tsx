import Image from 'next/image';
import Link from 'next/link';
import { Movie } from '../types/movie';

export default function HeroBanner({ movie }: { movie?: Movie }) {
  if (!movie) return null;
  const backdrop = movie.backdrop_path ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}` : null;

  return (
    <section className="relative h-72 md:h-96 rounded overflow-hidden">
      {backdrop && (
        <Image src={backdrop} alt={movie.title || movie.name || ''} fill priority style={{ objectFit: 'cover' }} />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
      <div className="absolute bottom-6 left-6 max-w-xl">
        <h2 className="text-2xl md:text-4xl font-bold">{movie.title || movie.name}</h2>
        <p className="mt-2 text-sm md:text-base line-clamp-3">{movie.overview}</p>
        <div className="mt-4">
          <Link href={`/movie/${movie.id}`} className="px-4 py-2 bg-red-600 rounded">View details</Link>
        </div>
      </div>
    </section>
  );
}
