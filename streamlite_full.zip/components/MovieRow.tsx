'use client';
import Link from 'next/link';
import Image from 'next/image';
import { Movie } from '../types/movie';

export default function MovieRow({ movies = [], categoryTitle = '' }: { movies: Movie[]; categoryTitle?: string }) {
  return (
    <section>
      <h3 className="text-lg font-semibold mb-2">{categoryTitle}</h3>
      <div className="flex gap-3 overflow-x-auto py-2 scrollbar-hide">
        {movies.map((m) => (
          <Link key={m.id} href={`/movie/${m.id}`} className="min-w-[150px] block flex-shrink-0">
            <div className="rounded overflow-hidden">
              <Image
                src={m.poster_path ? `https://image.tmdb.org/t/p/w342${m.poster_path}` : '/placeholder.png'}
                alt={m.title || m.name || ''}
                width={200}
                height={300}
                style={{ objectFit: 'cover' }}
              />
            </div>
            <p className="mt-1 text-sm">{m.title || m.name}</p>
          </Link>
        ))}
      </div>
    </section>
  );
}
