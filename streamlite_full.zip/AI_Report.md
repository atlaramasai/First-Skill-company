# AI_Report.md

## AI tools used
- ChatGPT — used to generate component scaffolding, TypeScript types, and helper functions.

## Usage
The AI provided initial code snippets which were reviewed and adjusted for Next.js 14 App Router and TypeScript.
