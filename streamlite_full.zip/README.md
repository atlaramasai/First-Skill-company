# StreamLite — Streaming Dashboard Clone

Minimal streaming-dashboard clone built with Next.js 14 (App Router), TypeScript and Tailwind CSS.
This scaffold includes server-side TMDB fetch helpers, homepage, dynamic movie detail pages, and deployment notes.

## Quick start

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create `.env.local` in project root:
   ```
   TMDB_API_KEY=your_tmdb_api_key_here
   ```

3. Run dev server:
   ```bash
   npm run dev
   # open http://localhost:3000
   ```

## Notes
- Do NOT commit `.env.local`
- Add `TMDB_API_KEY` in Vercel environment variables before deploying.
